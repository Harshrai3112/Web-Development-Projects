setTimeout(function () {
	var rock=document.querySelector("#rock") ;
	var paper=document.querySelector("#paper") ;
	var scissor=document.querySelector("#scissor");
	var result=document.getElementsByClassName("result");
	var btn=document.getElementById("button");
	var computerSelect=Math.floor(Math.random()*3);
	var userSelect;
	var res;
	var flag=0;
	rock.addEventListener("click",function(){
		if (flag==0) {
		userSelect=0;
		res=winner(userSelect,computerSelect);
		rock.classList.add("hover");
		result[0].textContent=res;
		flag=1;

		btn.textContent="Play Again";
		}

	}) 
	paper.addEventListener("click",function(){
		if (flag==0) {
		userSelect=1;
		paper.classList.add("hover");
		res=winner(userSelect,computerSelect);
		result[0].textContent=res;
		flag=1;
		btn.textContent="Play Again";
		}
	}) 
	scissor.addEventListener("click",function(){
		if (flag==0) {
		userSelect=2;
		scissor.classList.add("hover");
		res=winner(userSelect,computerSelect);
		result[0].textContent=res;
		flag=1;
		btn.textContent="Play Again";
		}
	}) 
	btn.addEventListener("click",function(){
		flag=0;

		result[0].textContent="";
		btn.textContent="";
		rock.classList.remove("hover");
		paper.classList.remove("hover");
		scissor.classList.remove("hover");

		computerSelect=Math.floor(Math.random()*3);
	})
	rock.addEventListener("mouseover",function(){
		if (flag==0) {
		rock.classList.add("hover");
		}
	})
	rock.addEventListener("mouseout",function(){
		if (flag==0) {
			rock.classList.remove("hover");
		}
	})
	paper.addEventListener("mouseover",function(){
		if (flag==0) {

		paper.classList.add("hover");
		}
	})
	paper.addEventListener("mouseout",function(){
		if (flag==0) {

		paper.classList.remove("hover");
		}
	})
	scissor.addEventListener("mouseover",function(){
		if (flag==0) {

		scissor.classList.add("hover");
		}
	})
	scissor.addEventListener("mouseout",function(){
		if (flag==0) {

		scissor.classList.remove("hover");
		}
	})
		
	function winner(userSelect,computerSelect){

		if(userSelect==0&&computerSelect==0){
			return "Its a Tie!!! Computer also Selected Rock ";
		}
		else if(userSelect==0&&computerSelect==1){
			return "You Lose !!! Computer Selected paper ";
		}
		else if(userSelect==0&&computerSelect==2){
			return "Hurry You Win!! " ;
		}
		else if(userSelect==1&&computerSelect==0){
			return "Hurry You Win!!! ";
		}
		else if(userSelect==1&&computerSelect==1){
			return "Its a Tie !!! Computer also Selected paper"; 
		}
		else if(userSelect==1&&computerSelect==2){
			return "You Lose!! Computer Selected scissor ";
		}
		else if(userSelect==2&&computerSelect==0){
			return "You Lose!!! Computer Selected paper";
		}
		else if(userSelect==2&&computerSelect==1){
			return "Hurry You Win !!!"
		}
		else {
			return "Its a tie!! Computer also Selected scissor";
		}
	}


},50)